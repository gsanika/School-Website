import React, { useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookingContext } from '../context/BookingContext';

const Confirmation = () => {
  const navigate = useNavigate();
  const { bookingData } = useContext(BookingContext);
  
  // Redirect if no booking data exists
  useEffect(() => {
    if (!bookingData || !bookingData.service) {
      navigate('/booking');
    }
  }, [bookingData, navigate]);
  
  if (!bookingData || !bookingData.service) {
    return null;
  }
  
  const formatDate = (dateObj) => {
    if (!dateObj) return '';
    return new Date(dateObj).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  const handleAddToCalendar = () => {
    const startDate = bookingData.date ? new Date(bookingData.date) : new Date();
    const endDate = new Date(startDate);
    
    // Parse time and add hours
    if (bookingData.time) {
      const timeParts = bookingData.time.match(/(\d+):(\d+) ([AP]M)/);
      if (timeParts) {
        let hours = parseInt(timeParts[1]);
        const minutes = parseInt(timeParts[2]);
        const ampm = timeParts[3];
        
        if (ampm === 'PM' && hours < 12) hours += 12;
        if (ampm === 'AM' && hours === 12) hours = 0;
        
        startDate.setHours(hours, minutes, 0, 0);
        
        // Add service duration (default to 2 hours if not specified)
        const durationHours = bookingData.service.duration 
          ? parseInt(bookingData.service.duration.match(/(\d+)/)[1]) 
          : 2;
        
        endDate.setHours(hours + durationHours, minutes, 0, 0);
      }
    }
    
    // Format for Google Calendar URL
    const startISOString = startDate.toISOString().replace(/-|:|\.\d+/g, '');
    const endISOString = endDate.toISOString().replace(/-|:|\.\d+/g, '');
    
    const eventDetails = {
      text: `Cleaning Service: ${bookingData.service.title}`,
      details: `Booking Reference: ${bookingData.bookingId}\nAddress: ${bookingData.formData.address}\nSpecial Instructions: ${bookingData.formData.specialInstructions || 'None'}`,
      location: bookingData.formData.address,
      dates: `${startISOString}/${endISOString}`
    };
    
    const googleCalendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(eventDetails.text)}&details=${encodeURIComponent(eventDetails.details)}&location=${encodeURIComponent(eventDetails.location)}&dates=${eventDetails.dates}`;
    
    window.open(googleCalendarUrl, '_blank');
  };
  
  return (
    <div className="confirmation-page">
      <div className="confirmation-container">
        <div className="confirmation-header">
          <div className="success-icon">
            <i className="check-mark"></i>
          </div>
          <h1>Booking Confirmed!</h1>
          <p className="confirmation-message">Thank you for choosing our cleaning services. Your booking has been successfully placed.</p>
        </div>
        
        <div className="booking-details">
          <h2>Booking Information</h2>
          <div className="confirmation-number">
            <p>Booking Reference: <strong>{bookingData.bookingId}</strong></p>
          </div>
          
          <div className="details-grid">
            <div className="detail-item">
              <h3>Service</h3>
              <p>{bookingData.service.title}</p>
              <p className="detail-meta">${bookingData.service.price} - {bookingData.service.duration}</p>
            </div>
            
            <div className="detail-item">
              <h3>Date & Time</h3>
              <p>{formatDate(bookingData.date)}</p>
              <p className="detail-meta">{bookingData.time}</p>
            </div>
            
            <div className="detail-item">
              <h3>Location</h3>
              <p>{bookingData.formData.address}</p>
            </div>
            
            <div className="detail-item">
              <h3>Contact Information</h3>
              <p>{bookingData.formData.name}</p>
              <p className="detail-meta">{bookingData.formData.email}</p>
              <p className="detail-meta">{bookingData.formData.phone}</p>
            </div>
          </div>
          
          {bookingData.formData.specialInstructions && (
            <div className="special-instructions">
              <h3>Special Instructions</h3>
              <p>{bookingData.formData.specialInstructions}</p>
            </div>
          )}
        </div>
        
        <div className="next-steps">
          <h2>What's Next?</h2>
          <div className="steps-list">
            <div className="step-item">
              <div className="step-number">1</div>
              <div className="step-content">
                <h3>Confirmation Email</h3>
                <p>You will receive a confirmation email with your booking details shortly.</p>
              </div>
            </div>
            
            <div className="step-item">
              <div className="step-number">2</div>
              <div className="step-content">
                <h3>Pre-Visit Call</h3>
                <p>A team member will contact you the day before your appointment to confirm.</p>
              </div>
            </div>
            
            <div className="step-item">
              <div className="step-number">3</div>
              <div className="step-content">
                <h3>Service Day</h3>
                <p>Our cleaning team will arrive at your location at the scheduled time.</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="confirmation-actions">
          <button className="btn-secondary" onClick={handleAddToCalendar}>
            Add to Calendar
          </button>
          <button className="btn-primary" onClick={() => navigate('/')}>
            Return to Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default Confirmation;