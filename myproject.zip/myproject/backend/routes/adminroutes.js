const express = require('express');
const {
  getDashboardStats,
  getUsers,
  getUser,
  createUser,
  updateUser,
  deleteUser,
  getRecentBookings,
  updateBookingStatus,
  getMonthlyRevenueReport
} = require('../controllers/admincontroller');

const router = express.Router();

// Import middleware
const { protect, authorize } = require('../middleware/auth');

// Apply middleware to all routes
router.use(protect);
router.use(authorize('admin'));

// Dashboard routes
router.get('/dashboard', getDashboardStats);
router.get('/bookings/recent', getRecentBookings);
router.get('/revenue/monthly', getMonthlyRevenueReport);

// User management routes
router.route('/users')
  .get(getUsers)
  .post(createUser);

router.route('/users/:id')
  .get(getUser)
  .put(updateUser)
  .delete(deleteUser);

// Booking management routes
router.put('/bookings/:id/status', updateBookingStatus);

module.exports = router;