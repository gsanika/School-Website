import React, { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import BookingForm from '../components/bookingform';
import DatePicker from '../components/DatePicker';
import { BookingContext } from '../context/BookingContext';

const Booking = () => {
  const navigate = useNavigate();
  const { bookingData, setBookingData } = useContext(BookingContext);
  
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedService, setSelectedService] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    specialInstructions: ''
  });
  
  const services = [
    {
      id: 1,
      title: "Standard Cleaning",
      description: "A thorough cleaning of all rooms with eco-friendly products.",
      price: 89,
      duration: "2 hours",
      image: "/images/standard-cleaning.jpg"
    },
    {
      id: 2,
      title: "Deep Cleaning",
      description: "An intensive cleaning service that reaches every corner and crevice.",
      price: 149,
      duration: "4 hours",
      image: "/images/deep-cleaning.jpg"
    },
    {
      id: 3,
      title: "Move-in/Move-out",
      description: "Prepare your space for new tenants or make it spotless when you leave.",
      price: 199,
      duration: "5 hours",
      image: "/images/move-in-out.jpg"
    }
  ];
  
  const availableTimes = [
    "9:00 AM",
    "11:00 AM",
    "1:00 PM",
    "3:00 PM",
    "5:00 PM"
  ];
  
  // Load data from context if available
  useEffect(() => {
    if (bookingData.service) {
      setSelectedService(bookingData.service);
    }
    if (bookingData.date) {
      setSelectedDate(bookingData.date);
    }
    if (bookingData.time) {
      setSelectedTime(bookingData.time);
    }
    if (bookingData.formData) {
      setFormData(bookingData.formData);
    }
  }, [bookingData]);
  
  const nextStep = () => {
    if (currentStep === 1 && !selectedService) {
      alert("Please select a service to continue");
      return;
    }
    
    if (currentStep === 2 && (!selectedDate || !selectedTime)) {
      alert("Please select a date and time to continue");
      return;
    }
    
    // Save current step data to context
    setBookingData({
      ...bookingData,
      service: selectedService,
      date: selectedDate,
      time: selectedTime,
      formData: formData
    });
    
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    } else {
      // Submit booking
      handleSubmit();
    }
  };
  
  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };
  
  const handleServiceSelect = (service) => {
    setSelectedService(service);
  };
  
  const handleDateSelect = (date) => {
    setSelectedDate(date);
  };
  
  const handleTimeSelect = (time) => {
    setSelectedTime(time);
  };
  
  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  const handleSubmit = () => {
    // In a real application, you would send the data to your backend here
    console.log("Booking submitted:", {
      service: selectedService,
      date: selectedDate,
      time: selectedTime,
      customerInfo: formData
    });
    
    // Save complete booking data to context
    setBookingData({
      service: selectedService,
      date: selectedDate,
      time: selectedTime,
      formData: formData,
      bookingId: `BK${Math.floor(100000 + Math.random() * 900000)}`
    });
    
    // Navigate to confirmation page
    navigate('/confirmation');
  };
  
  return (
    <div className="booking-page">
      <div className="booking-header">
        <h1>Book Your Cleaning Service</h1>
        <div className="booking-progress">
          <div className={`progress-step ${currentStep >= 1 ? 'active' : ''}`}>
            <div className="step-number">1</div>
            <div className="step-title">Select Service</div>
          </div>
          <div className="progress-line"></div>
          <div className={`progress-step ${currentStep >= 2 ? 'active' : ''}`}>
            <div className="step-number">2</div>
            <div className="step-title">Choose Date & Time</div>
          </div>
          <div className="progress-line"></div>
          <div className={`progress-step ${currentStep >= 3 ? 'active' : ''}`}>
            <div className="step-number">3</div>
            <div className="step-title">Your Details</div>
          </div>
        </div>
      </div>
      
      <div className="booking-content">
        {currentStep === 1 && (
          <div className="service-selection">
            <h2>Choose Your Service</h2>
            <div className="services-list">
              {services.map(service => (
                <div 
                  key={service.id}
                  className={`service-item ${selectedService && selectedService.id === service.id ? 'selected' : ''}`}
                  onClick={() => handleServiceSelect(service)}
                >
                  <div className="service-image">
                    <img src={service.image} alt={service.title} />
                  </div>
                  <div className="service-details">
                    <h3>{service.title}</h3>
                    <p>{service.description}</p>
                    <div className="service-meta">
                      <span className="service-price">${service.price}</span>
                      <span className="service-duration">{service.duration}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {currentStep === 2 && (
          <div className="date-time-selection">
            <h2>Select Date & Time</h2>
            <div className="date-time-container">
              <div className="date-picker-container">
                <h3>Choose a Date</h3>
                <DatePicker onDateSelect={handleDateSelect} selectedDate={selectedDate} />
              </div>
              <div className="time-slots">
                <h3>Available Time Slots</h3>
                <div className="time-options">
                  {availableTimes.map(time => (
                    <button
                      key={time}
                      className={`time-option ${selectedTime === time ? 'selected' : ''}`}
                      onClick={() => handleTimeSelect(time)}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
        
        {currentStep === 3 && (
          <div className="customer-details">
            <h2>Your Information</h2>
            <BookingForm formData={formData} handleChange={handleFormChange} />
            
            <div className="booking-summary">
              <h3>Booking Summary</h3>
              <div className="summary-details">
                <div className="summary-row">
                  <span className="summary-label">Service:</span>
                  <span className="summary-value">{selectedService?.title}</span>
                </div>
                <div className="summary-row">
                  <span className="summary-label">Date:</span>
                  <span className="summary-value">{selectedDate?.toLocaleDateString()}</span>
                </div>
                <div className="summary-row">
                  <span className="summary-label">Time:</span>
                  <span className="summary-value">{selectedTime}</span>
                </div>
                <div className="summary-row">
                  <span className="summary-label">Price:</span>
                  <span className="summary-value">${selectedService?.price}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      <div className="booking-actions">
        {currentStep > 1 && (
          <button className="btn-secondary" onClick={prevStep}>Previous</button>
        )}
        <button className="btn-primary" onClick={nextStep}>
          {currentStep < 3 ? 'Next' : 'Confirm Booking'}
        </button>
      </div>
    </div>
  );
};

export default Booking;