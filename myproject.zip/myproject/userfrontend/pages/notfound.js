import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => {
  return (
    <div className="not-found">
      <div className="not-found-container">
        <div className="error-code">404</div>
        <h1>Page Not Found</h1>
        <p>Oops! The page you are looking for does not exist or has been moved.</p>
        
        <div className="not-found-illustration">
          <div className="cleaning-character">
            <div className="character-head"></div>
            <div className="character-body"></div>
            <div className="mop"></div>
          </div>
          <div className="speech-bubble">
            Let me help you find your way back!
          </div>
        </div>
        
        <div className="suggested-links">
          <h2>You might be looking for:</h2>
          <ul className="links-list">
            <li>
              <Link to="/">Home Page</Link>
              <span className="link-description">Return to our main page</span>
            </li>
            <li>
              <Link to="/services">Our Services</Link>
              <span className="link-description">Browse all cleaning services</span>
            </li>
            <li>
              <Link to="/booking">Book a Service</Link>
              <span className="link-description">Schedule a cleaning appointment</span>
            </li>
          </ul>
        </div>
        
        <div className="back-to-home">
          <Link to="/" className="home-button">Return to Homepage</Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;