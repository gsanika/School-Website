const express = require('express');
const {
  getServices,
  getService,
  createService,
  updateService,
  deleteService,
  uploadServiceImage,
  getServicesByCategory,
  toggleServiceAvailability
} = require('../controllers/servicecontroller');

const router = express.Router();

// Import middleware
const { protect, authorize } = require('../middleware/auth');

router.route('/')
  .get(getServices)
  .post(protect, authorize('admin'), createService);

router.route('/:id')
  .get(getService)
  .put(protect, authorize('admin'), updateService)
  .delete(protect, authorize('admin'), deleteService);

router.put('/:id/image', protect, authorize('admin'), uploadServiceImage);
router.get('/category/:category', getServicesByCategory);
router.put('/:id/toggle-availability', protect, authorize('admin'), toggleServiceAvailability);

module.exports = router;