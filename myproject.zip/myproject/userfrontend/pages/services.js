import React, { useState } from 'react';
import ServiceCard from '../components/ServiceCard';

const Services = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  
  const categories = [
    { id: 'all', name: 'All Services' },
    { id: 'residential', name: 'Residential' },
    { id: 'commercial', name: 'Commercial' },
    { id: 'specialized', name: 'Specialized' }
  ];
  
  const allServices = [
    {
      id: 1,
      title: "Standard Cleaning",
      description: "A thorough cleaning of all rooms with eco-friendly products.",
      price: 89,
      duration: "2 hours",
      image: "/images/standard-cleaning.jpg",
      category: "residential"
    },
    {
      id: 2,
      title: "Deep Cleaning",
      description: "An intensive cleaning service that reaches every corner and crevice.",
      price: 149,
      duration: "4 hours",
      image: "/images/deep-cleaning.jpg",
      category: "residential"
    },
    {
      id: 3,
      title: "Move-in/Move-out",
      description: "Prepare your space for new tenants or make it spotless when you leave.",
      price: 199,
      duration: "5 hours",
      image: "/images/move-in-out.jpg",
      category: "residential"
    },
    {
      id: 4,
      title: "Office Cleaning",
      description: "Keep your workplace fresh, clean and professional.",
      price: 129,
      duration: "3 hours",
      image: "/images/office-cleaning.jpg",
      category: "commercial"
    },
    {
      id: 5,
      title: "Post-Construction",
      description: "Remove debris and clean thoroughly after construction work.",
      price: 249,
      duration: "6 hours",
      image: "/images/post-construction.jpg",
      category: "specialized"
    },
    {
      id: 6,
      title: "Retail Space Cleaning",
      description: "Maintain a clean shopping environment for your customers.",
      price: 159,
      duration: "3 hours",
      image: "/images/retail-cleaning.jpg",
      category: "commercial"
    }
  ];
  
  const filteredServices = selectedCategory === 'all' 
    ? allServices 
    : allServices.filter(service => service.category === selectedCategory);

  return (
    <div className="services-page">
      <div className="services-hero">
        <h1>Our Cleaning Services</h1>
        <p>Professional cleaning solutions for every space and need</p>
      </div>
      
      <div className="category-filter">
        <div className="filter-tabs">
          {categories.map(category => (
            <button 
              key={category.id}
              className={`filter-tab ${selectedCategory === category.id ? 'active' : ''}`}
              onClick={() => setSelectedCategory(category.id)}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>
      
      <div className="services-grid">
        {filteredServices.length > 0 ? (
          filteredServices.map(service => (
            <ServiceCard 
              key={service.id} 
              service={service} 
              showBookButton={true}
            />
          ))
        ) : (
          <p className="no-services">No services found in this category.</p>
        )}
      </div>
      
      <div className="custom-request">
        <h2>Need a Custom Service?</h2>
        <p>Don't see what you're looking for? Contact us for a customized cleaning solution.</p>
        <button className="custom-request-btn">Request Custom Quote</button>
      </div>
      
      <div className="service-guarantees">
        <h2>Our Guarantees</h2>
        <div className="guarantees-grid">
          <div className="guarantee-item">
            <i className="guarantee-icon satisfaction"></i>
            <h3>100% Satisfaction</h3>
            <p>If you're not happy with our service, we'll come back and make it right.</p>
          </div>
          <div className="guarantee-item">
            <i className="guarantee-icon insured"></i>
            <h3>Fully Insured</h3>
            <p>Our services are fully insured for your peace of mind.</p>
          </div>
          <div className="guarantee-item">
            <i className="guarantee-icon secure"></i>
            <h3>Secure Booking</h3>
            <p>Your personal and payment information is always protected.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;