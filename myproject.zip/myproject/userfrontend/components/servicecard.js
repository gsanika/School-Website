import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useContext } from 'react';
import { BookingContext } from '../context/BookingContext';

const ServiceCard = ({ service, showBookButton = false }) => {
  const navigate = useNavigate();
  const { setBookingData } = useContext(BookingContext);
  
  const handleBookService = () => {
    // Store selected service in context
    setBookingData(prevData => ({
      ...prevData,
      service: service
    }));
    
    // Navigate to booking page
    navigate('/booking');
  };
  
  // Generate a CSS class based on category for styling
  const categoryClass = service.category ? `service-category-${service.category}` : '';
  
  return (
    <div className={`service-card ${categoryClass}`}>
      <div className="service-card-image">
        {service.image && (
          <img 
            src={service.image} 
            alt={service.title} 
            className="service-image"
          />
        )}
        {service.category && (
          <span className="service-category-tag">{service.category}</span>
        )}
      </div>
      
      <div className="service-card-content">
        <h3 className="service-title">{service.title}</h3>
        
        <div className="service-meta">
          <div className="service-price">${service.price}</div>
          <div className="service-duration">{service.duration}</div>
        </div>
        
        <p className="service-description">{service.description}</p>
        
        <div className="service-features">
          {service.features && service.features.map((feature, index) => (
            <div key={index} className="service-feature">
              <i className="feature-icon check"></i>
              <span>{feature}</span>
            </div>
          ))}
        </div>
        
        <div className="service-card-actions">
          {showBookButton ? (
            <button 
              className="book-service-btn" 
              onClick={handleBookService}
            >
              Book Now
            </button>
          ) : (
            <button 
              className="learn-more-btn"
              onClick={() => navigate(`/services/${service.id}`)}
            >
              Learn More
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;