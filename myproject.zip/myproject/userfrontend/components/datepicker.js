import React, { useState, useEffect } from 'react';

const DatePicker = ({ onDateSelect, selectedDate }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [calendarDays, setCalendarDays] = useState([]);
  
  // Get current date to disable past dates
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // Generate calendar days for the current month view
  useEffect(() => {
    generateCalendarDays(currentMonth);
  }, [currentMonth]);
  
  const generateCalendarDays = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    
    // First day of the month
    const firstDay = new Date(year, month, 1);
    // Last day of the month
    const lastDay = new Date(year, month + 1, 0);
    
    // Get the day of the week for the first day (0 = Sunday, 1 = Monday, etc.)
    const firstDayOfWeek = firstDay.getDay();
    
    // Calculate days from previous month to show
    const daysFromPrevMonth = firstDayOfWeek;
    
    // Total days to show in the calendar view (previous month + current month + next month)
    const totalDays = 42; // 6 rows of 7 days
    
    // Generate array of calendar day objects
    const days = [];
    
    // Add days from previous month
    const prevMonth = new Date(year, month, 0);
    const prevMonthLastDay = prevMonth.getDate();
    
    for (let i = 0; i < daysFromPrevMonth; i++) {
      const day = prevMonthLastDay - daysFromPrevMonth + i + 1;
      days.push({
        date: new Date(year, month - 1, day),
        day,
        isCurrentMonth: false,
        isPast: new Date(year, month - 1, day) < today
      });
    }
    
    // Add days from current month
    for (let day = 1; day <= lastDay.getDate(); day++) {
      const date = new Date(year, month, day);
      days.push({
        date,
        day,
        isCurrentMonth: true,
        isPast: date < today
      });
    }
    
    // Add days from next month if needed to fill the calendar
    const remainingDays = totalDays - days.length;
    for (let day = 1; day <= remainingDays; day++) {
      days.push({
        date: new Date(year, month + 1, day),
        day,
        isCurrentMonth: false,
        isPast: false // Future dates are never in the past
      });
    }
    
    setCalendarDays(days);
  };
  
  // Go to previous month
  const prevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };
  
  // Go to next month
  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };
  
  // Format month name
  const formatMonth = (date) => {
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };
  
  // Check if a date is selected
  const isDateSelected = (date) => {
    if (!selectedDate) return false;
    
    return date.getFullYear() === selectedDate.getFullYear() &&
           date.getMonth() === selectedDate.getMonth() &&
           date.getDate() === selectedDate.getDate();
  };
  
  // Format day number with leading zero if needed
  const formatDay = (day) => {
    return day < 10 ? `0${day}` : day;
  };
  
  // Handle date selection
  const handleDateClick = (day) => {
    if (!day.isPast) {
      onDateSelect(day.date);
    }
  };
  
  // Check if a day is today
  const isToday = (date) => {
    return date.getFullYear() === today.getFullYear() &&
           date.getMonth() === today.getMonth() &&
           date.getDate() === today.getDate();
  };
  
  const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  return (
    <div className="date-picker">
      <div className="date-picker-header">
        <button 
          className="month-nav prev-month" 
          onClick={prevMonth}
          disabled={currentMonth <= today}
        >
          &lt;
        </button>
        <div className="current-month">{formatMonth(currentMonth)}</div>
        <button className="month-nav next-month" onClick={nextMonth}>
          &gt;
        </button>
      </div>
      
      <div className="weekdays">
        {weekdays.map(day => (
          <div key={day} className="weekday">{day}</div>
        ))}
      </div>
      
      <div className="calendar-days">
        {calendarDays.map((day, index) => (
          <div 
            key={index}
            className={`calendar-day ${day.isCurrentMonth ? 'current-month' : 'other-month'} 
                       ${day.isPast ? 'past-day' : ''} 
                       ${isDateSelected(day.date) ? 'selected' : ''} 
                       ${isToday(day.date) ? 'today' : ''}`}
            onClick={() => handleDateClick(day)}
          >
            <div className="day-number">{formatDay(day.day)}</div>
          </div>
        ))}
      </div>
      
      <div className="date-picker-footer">
        <div className="date-picker-legend">
          <div className="legend-item">
            <div className="legend-color today"></div>
            <span>Today</span>
          </div>
          <div className="legend-item">
            <div className="legend-color selected"></div>
            <span>Selected</span>
          </div>
          <div className="legend-item">
            <div className="legend-color unavailable"></div>
            <span>Unavailable</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DatePicker;