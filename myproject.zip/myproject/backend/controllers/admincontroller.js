const User = require('../models/users');
const Booking = require('../models/booking');
const Service = require('../models/service');

// Get dashboard stats
exports.getDashboardStats = async (req, res, next) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to access admin statistics' });
    }
    
    // Get counts
    const userCount = await User.countDocuments({ role: 'user' });
    const serviceCount = await Service.countDocuments();
    const bookingCount = await Booking.countDocuments();
    
    // Get pending bookings count
    const pendingBookings = await Booking.countDocuments({ status: 'pending' });
    
    // Get confirmed bookings count
    const confirmedBookings = await Booking.countDocuments({ status: 'confirmed' });
    
    // Get cancelled bookings count
    const cancelledBookings = await Booking.countDocuments({ status: 'cancelled' });
    
    // Get completed bookings count
    const completedBookings = await Booking.countDocuments({ status: 'completed' });
    
    // Get revenue data
    const bookings = await Booking.find({ status: { $in: ['confirmed', 'completed'] } });
    const totalRevenue = bookings.reduce((total, booking) => total + booking.totalPrice, 0);
    
    // Get today's bookings - Fix: Create new Date objects to avoid modification
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
    const endOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
    
    const todayBookings = await Booking.countDocuments({
      date: { $gte: startOfToday, $lte: endOfToday }
    });
    
    // Get this month's revenue - Fix: Create new Date objects to avoid modification
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
    
    const monthBookings = await Booking.find({
      createdAt: { $gte: startOfMonth, $lte: endOfMonth },
      status: { $in: ['confirmed', 'completed'] }
    });
    
    const monthRevenue = monthBookings.reduce((total, booking) => total + booking.totalPrice, 0);
    
    res.status(200).json({
      success: true,
      data: {
        users: userCount,
        services: serviceCount,
        bookings: bookingCount,
        pendingBookings,
        confirmedBookings,
        cancelledBookings,
        completedBookings,
        totalRevenue,
        todayBookings,
        monthRevenue
      }
    });
  } catch (error) {
    next(error);
  }
};

// Get all users
exports.getUsers = async (req, res, next) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to access user data' });
    }
    
    const allUsers = await User.find({ role: 'user' }).select('-password');
    
    res.status(200).json({
      success: true,
      count: allUsers.length,
      data: allUsers
    });
  } catch (error) {
    next(error);
  }
};

// Get a single user
exports.getUser = async (req, res, next) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to access user data' });
    }
    
    const user = await User.findById(req.params.id).select('-password');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// Create a user (admin function)
exports.createUser = async (req, res, next) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to create users' });
    }
    
    const { name, email, phone, password, role } = req.body;
    
    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists with this email' });
    }
    
    // Create new user
    const user = await User.create({
      name,
      email,
      phone,
      password,
      role
    });
    
    res.status(201).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// Update user details (admin function)
exports.updateUser = async (req, res, next) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to update users' });
    }
    
    const user = await User.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    }).select('-password');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
};

// Delete user (admin function)
exports.deleteUser = async (req, res, next) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to delete users' });
    }
    
    const user = await User.findById(req.params.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Find and delete all user's bookings
    await Booking.deleteMany({ user: user._id });
    
    // Delete the user - Fix: Use deleteOne() consistently
    await user.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

// Get recent bookings
exports.getRecentBookings = async (req, res, next) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to access booking data' });
    }
    
    const bookings = await Booking.find()
      .sort('-createdAt')
      .limit(10)
      .populate({
        path: 'user',
        select: 'name email'
      })
      .populate({
        path: 'service',
        select: 'name price'
      });
    
    res.status(200).json({
      success: true,
      count: bookings.length,
      data: bookings
    });
  } catch (error) {
    next(error);
  }
};

// Update booking status
exports.updateBookingStatus = async (req, res, next) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to update booking status' });
    }
    
    const { status } = req.body;
    
    // Validate status
    if (!['pending', 'confirmed', 'cancelled', 'completed'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status value' });
    }
    
    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    )
    .populate({
      path: 'user',
      select: 'name email'
    })
    .populate({
      path: 'service',
      select: 'name price'
    });
    
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }
    
    res.status(200).json({
      success: true,
      data: booking
    });
  } catch (error) {
    next(error);
  }
};

// Get monthly revenue report
exports.getMonthlyRevenueReport = async (req, res, next) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to access revenue data' });
    }
    
    const { year, month } = req.query;
    
    // Default to current year and month if not provided
    const targetYear = year ? parseInt(year) : new Date().getFullYear();
    const targetMonth = month ? parseInt(month) - 1 : new Date().getMonth();
    
    const startDate = new Date(targetYear, targetMonth, 1);
    const endDate = new Date(targetYear, targetMonth + 1, 0, 23, 59, 59, 999);
    
    const bookings = await Booking.find({
      date: { $gte: startDate, $lte: endDate },
      status: { $in: ['confirmed', 'completed'] }
    }).populate({
      path: 'service',
      select: 'name price'
    });
    
    const totalRevenue = bookings.reduce((total, booking) => total + booking.totalPrice, 0);
    
    // Group by day
    const dailyRevenue = {};
    for (let i = 1; i <= endDate.getDate(); i++) {
      dailyRevenue[i] = 0;
    }
    
    bookings.forEach(booking => {
      const day = booking.date.getDate();
      dailyRevenue[day] += booking.totalPrice;
    });
    
    res.status(200).json({
      success: true,
      data: {
        year: targetYear,
        month: targetMonth + 1,
        totalRevenue,
        dailyRevenue
      }
    });
  } catch (error) {
    next(error);
  }
};