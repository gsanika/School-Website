import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="site-footer">
      <div className="footer-top">
        <div className="footer-container">
          <div className="footer-grid">
            <div className="footer-column company-info">
              <Link to="/" className="footer-logo">
                <img src="/images/logo-white.svg" alt="CleanCo Logo" className="footer-logo-image" />
                <span className="footer-logo-text">CleanCo</span>
              </Link>
              <p className="company-description">
                Professional cleaning services for residential and commercial spaces. 
                We bring sparkle to every corner with eco-friendly products.
              </p>
              <div className="social-links">
                <a href="https://facebook.com" className="social-link" aria-label="Facebook">
                  <i className="social-icon facebook"></i>
                </a>
                <a href="https://instagram.com" className="social-link" aria-label="Instagram">
                  <i className="social-icon instagram"></i>
                </a>
                <a href="https://twitter.com" className="social-link" aria-label="Twitter">
                  <i className="social-icon twitter"></i>
                </a>
                <a href="https://linkedin.com" className="social-link" aria-label="LinkedIn">
                  <i className="social-icon linkedin"></i>
                </a>
              </div>
            </div>

            <div className="footer-column quick-links">
              <h3 className="footer-heading">Quick Links</h3>
              <ul className="footer-links">
                <li><Link to="/">Home</Link></li>
                <li><Link to="/services">Services</Link></li>
                <li><Link to="/about">About Us</Link></li>
                <li><Link to="/contact">Contact</Link></li>
                <li><Link to="/booking">Book a Service</Link></li>
              </ul>
            </div>

            <div className="footer-column services">
              <h3 className="footer-heading">Our Services</h3>
              <ul className="footer-links">
                <li><Link to="/services#residential">Residential Cleaning</Link></li>
                <li><Link to="/services#commercial">Commercial Cleaning</Link></li>
                <li><Link to="/services#deep-cleaning">Deep Cleaning</Link></li>
                <li><Link to="/services#move-in-out">Move In/Out Cleaning</Link></li>
                <li><Link to="/services#specialized">Specialized Services</Link></li>
              </ul>
            </div>

            <div className="footer-column contact-info">
              <h3 className="footer-heading">Contact Us</h3>
              <address className="footer-address">
                <p className="contact-item">
                  <i className="contact-icon location"></i>
                  123 Cleaning Street, Sparkle City
                </p>
                <p className="contact-item">
                  <i className="contact-icon phone"></i>
                  <a href="tel:+11234567890">(123) 456-7890</a>
                </p>
                <p className="contact-item">
                  <i className="contact-icon email"></i>
                  <a href="mailto:info@cleancoservices.com">info@cleancoservices.com</a>
                </p>
                <p className="contact-item">
                  <i className="contact-icon clock"></i>
                  Mon-Fri: 8AM-6PM, Sat: 9AM-4PM
                </p>
              </address>
            </div>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="footer-container">
          <div className="copyright">
            <p>&copy; {currentYear} CleanCo Services. All rights reserved.</p>
          </div>
          <div className="legal-links">
            <Link to="/privacy-policy">Privacy Policy</Link>
            <Link to="/terms-of-service">Terms of Service</Link>
            <Link to="/sitemap">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;