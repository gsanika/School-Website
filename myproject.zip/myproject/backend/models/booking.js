const mongoose = require('mongoose');

const BookingSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'users',
    required: true
  },
  service: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'service',
    required: true
  },
  date: {
    type: Date,
    required: [true, 'Please provide a date and time for the booking']
  },
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'cancelled', 'completed'],
    default: 'pending'
  },
  notes: {
    type: String,
    maxlength: 500
  },
  totalPrice: {
    type: Number,
    required: true
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'paid', 'refunded'],
    default: 'pending'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create index for querying bookings by date
BookingSchema.index({ date: 1 });

// Method to check if booking time is available
BookingSchema.statics.isTimeAvailable = async function(serviceId, date, excludeBookingId = null) {
  const bookingTime = new Date(date);
  
  // Get the service to check duration
  const Service = mongoose.model('service');
  const service = await Service.findById(serviceId);
  
  if (!service) {
    return false;
  }
  
  // Calculate booking end time based on service duration
  const bookingEndTime = new Date(bookingTime.getTime() + service.duration * 60000);
  
  const startOfDay = new Date(bookingTime.getFullYear(), bookingTime.getMonth(), bookingTime.getDate(), 0, 0, 0, 0);
  const endOfDay = new Date(bookingTime.getFullYear(), bookingTime.getMonth(), bookingTime.getDate(), 23, 59, 59, 999);
  
  const query = {
    service: serviceId,
    date: { $gte: startOfDay, $lte: endOfDay },
    status: { $ne: 'cancelled' }
  };
  
  // Exclude current booking when checking for updates
  if (excludeBookingId) {
    query._id = { $ne: excludeBookingId };
  }
  
  const bookings = await this.find(query);
  
  // Check for overlapping time slots
  for (const booking of bookings) {
    const existingBookingTime = new Date(booking.date);
    const existingBookingEndTime = new Date(existingBookingTime.getTime() + service.duration * 60000);
    
    // Check if the requested booking overlaps with an existing booking
    if (
      (bookingTime >= existingBookingTime && bookingTime < existingBookingEndTime) ||
      (bookingEndTime > existingBookingTime && bookingEndTime <= existingBookingEndTime) ||
      (bookingTime <= existingBookingTime && bookingEndTime >= existingBookingEndTime)
    ) {
      return false;
    }
  }
  
  return true;
};

module.exports = mongoose.model('booking', BookingSchema);