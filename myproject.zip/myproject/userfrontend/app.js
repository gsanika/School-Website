import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Import context provider
import BookingProvider from './context/BookingContext';

// Import components
import Navbar from './components/navbar';
import Footer from './components/footer';

// Import pages
import Home from './pages/Home';
import Services from './pages/Services';
import Booking from './pages/Booking';
import Confirmation from './pages/Confirmation';
import NotFound from './pages/notfound';

// Import styles
import './styles/main.css';

function App() {
  return (
    <Router>
      <BookingProvider>
        <div className="app">
          <Navbar />
          <main className="main-content">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/services" element={<Services />} />
              <Route path="/booking" element={<Booking />} />
              <Route path="/confirmation" element={<Confirmation />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </BookingProvider>
    </Router>
  );
}

export default App;