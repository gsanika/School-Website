import React from 'react';

const BookingForm = ({ formData, handleChange }) => {
  return (
    <div className="booking-form">
      <div className="form-row">
        <div className="form-group">
          <label htmlFor="name" className="form-label">Full Name *</label>
          <input
            type="text"
            id="name"
            name="name"
            className="form-control"
            value={formData.name}
            onChange={handleChange}
            required
            placeholder="Enter your full name"
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="email" className="form-label">Email Address *</label>
          <input
            type="email"
            id="email"
            name="email"
            className="form-control"
            value={formData.email}
            onChange={handleChange}
            required
            placeholder="Enter your email address"
          />
        </div>
      </div>
      
      <div className="form-row">
        <div className="form-group">
          <label htmlFor="phone" className="form-label">Phone Number *</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            className="form-control"
            value={formData.phone}
            onChange={handleChange}
            required
            placeholder="Enter your phone number"
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="propertyType" className="form-label">Property Type</label>
          <select
            id="propertyType"
            name="propertyType"
            className="form-control"
            value={formData.propertyType || ''}
            onChange={handleChange}
          >
            <option value="">Select property type</option>
            <option value="apartment">Apartment</option>
            <option value="house">House</option>
            <option value="office">Office Space</option>
            <option value="commercial">Commercial Property</option>
            <option value="other">Other</option>
          </select>
        </div>
      </div>
      
      <div className="form-row full-width">
        <div className="form-group">
          <label htmlFor="address" className="form-label">Service Address *</label>
          <input
            type="text"
            id="address"
            name="address"
            className="form-control"
            value={formData.address}
            onChange={handleChange}
            required
            placeholder="Enter the full address where service will be performed"
          />
        </div>
      </div>
      
      <div className="form-row full-width">
        <div className="form-group">
          <label htmlFor="specialInstructions" className="form-label">Special Instructions</label>
          <textarea
            id="specialInstructions"
            name="specialInstructions"
            className="form-control"
            value={formData.specialInstructions}
            onChange={handleChange}
            rows="4"
            placeholder="Please provide any additional instructions or special requirements"
          ></textarea>
        </div>
      </div>
      
      <div className="form-row">
        <div className="form-group checkbox-group">
          <input
            type="checkbox"
            id="pet"
            name="hasPets"
            checked={formData.hasPets || false}
            onChange={(e) => handleChange({
              target: {
                name: e.target.name,
                value: e.target.checked
              }
            })}
          />
          <label htmlFor="pet" className="checkbox-label">I have pets at home</label>
        </div>
        
        <div className="form-group checkbox-group">
          <input
            type="checkbox"
            id="access"
            name="providingAccess"
            checked={formData.providingAccess || false}
            onChange={(e) => handleChange({
              target: {
                name: e.target.name,
                value: e.target.checked
              }
            })}
          />
          <label htmlFor="access" className="checkbox-label">I will be present to provide access</label>
        </div>
      </div>
      
      <div className="form-row full-width">
        <div className="form-group checkbox-group">
          <input
            type="checkbox"
            id="terms"
            name="termsAccepted"
            checked={formData.termsAccepted || false}
            onChange={(e) => handleChange({
              target: {
                name: e.target.name,
                value: e.target.checked
              }
            })}
            required
          />
          <label htmlFor="terms" className="checkbox-label">
            I agree to the <a href="/terms" className="terms-link">Terms and Conditions</a> *
          </label>
        </div>
      </div>
      
      <div className="form-note">
        <p>* Required fields</p>
      </div>
    </div>
  );
};

export default BookingForm;