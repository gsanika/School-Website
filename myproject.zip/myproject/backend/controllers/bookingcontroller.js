const Booking = require('../models/booking');
const Service = require('../models/service');
const User = require('../models/users');
const nodemailer = require('nodemailer');

// Get all bookings
exports.getBookings = async (req, res, next) => {
  try {
    // For regular users, only return their own bookings
    let query;
    
    if (req.user.role !== 'admin') {
      query = Booking.find({ user: req.user.id });
    } else {
      // For admins, can filter by query parameters
      query = Booking.find(req.query);
    }
    
    // Populate with service and user details
    query = query.populate({
      path: 'service',
      select: 'name price duration'
    }).populate({
      path: 'user',
      select: 'name email phone'
    });
    
    const bookings = await query;
    
    res.status(200).json({
      success: true,
      count: bookings.length,
      data: bookings
    });
  } catch (error) {
    next(error);
  }
};

// Get single booking
exports.getBooking = async (req, res, next) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate({
        path: 'service',
        select: 'name price duration description'
      })
      .populate({
        path: 'user',
        select: 'name email phone'
      });
      
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }
    
    // Make sure user is booking owner or admin
    if (booking.user._id.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({ message: 'Not authorized to access this booking' });
    }
    
    res.status(200).json({
      success: true,
      data: booking
    });
  } catch (error) {
    next(error);
  }
};

// Create new booking
exports.createBooking = async (req, res, next) => {
  try {
    // Add user ID to request body
    req.body.user = req.user.id;
    
    // Check if service exists
    const service = await Service.findById(req.body.service);
    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }
    
    // Check if service is available
    if (!service.isAvailable) {
      return res.status(400).json({ message: 'This service is currently unavailable' });
    }
    
    // Check if time slot is available
    const isAvailable = await Booking.isTimeAvailable(
      req.body.service,
      req.body.date
    );
    
    if (!isAvailable) {
      return res.status(400).json({ message: 'This time slot is already booked' });
    }
    
    // Create booking
    const booking = await Booking.create({
      ...req.body,
      totalPrice: service.price
    });
    
    // Send confirmation email
    await sendBookingConfirmationEmail(booking, service, req.user);
    
    res.status(201).json({
      success: true,
      data: booking
    });
  } catch (error) {
    next(error);
  }
};

// Update booking
exports.updateBooking = async (req, res, next) => {
  try {
    let booking = await Booking.findById(req.params.id);
    
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }
    
    // Make sure user is booking owner or admin
    if (booking.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({ message: 'Not authorized to update this booking' });
    }
    
    // If updating date, check if new time slot is available
    if (req.body.date && req.body.date !== booking.date) {
      const isAvailable = await Booking.isTimeAvailable(
        booking.service,
        req.body.date,
        booking._id
      );
      
      if (!isAvailable) {
        return res.status(400).json({ message: 'This time slot is already booked' });
      }
    }
    
    booking = await Booking.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });
    
    res.status(200).json({
      success: true,
      data: booking
    });
  } catch (error) {
    next(error);
  }
};

// Delete booking
exports.deleteBooking = async (req, res, next) => {
  try {
    const booking = await Booking.findById(req.params.id);
    
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }
    
    // Make sure user is booking owner or admin
    if (booking.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({ message: 'Not authorized to delete this booking' });
    }
    
    // Fix: Use deleteOne() instead of remove()
    await booking.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

// Cancel booking
exports.cancelBooking = async (req, res, next) => {
  try {
    const booking = await Booking.findById(req.params.id);
    
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }
    
    // Make sure user is booking owner or admin
    if (booking.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(401).json({ message: 'Not authorized to cancel this booking' });
    }
    
    // Only allow cancellation if status is pending or confirmed
    if (!['pending', 'confirmed'].includes(booking.status)) {
      return res.status(400).json({ message: `Booking cannot be cancelled in '${booking.status}' status` });
    }
    
    booking.status = 'cancelled';
    await booking.save();
    
    res.status(200).json({
      success: true,
      data: booking
    });
  } catch (error) {
    next(error);
  }
};

// Get available time slots for a service on a specific date
exports.getAvailableTimeSlots = async (req, res, next) => {
  try {
    const { serviceId, date } = req.params;
    
    // Check if service exists
    const service = await Service.findById(serviceId);
    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }
    
    // Get all available time slots
    const availableSlots = service.getAvailableTimeSlots(date);
    
    // Get all bookings for this service on this date
    const bookingDate = new Date(date);
    const startOfDay = new Date(bookingDate.getFullYear(), bookingDate.getMonth(), bookingDate.getDate(), 0, 0, 0, 0);
    const endOfDay = new Date(bookingDate.getFullYear(), bookingDate.getMonth(), bookingDate.getDate(), 23, 59, 59, 999);
    
    const bookings = await Booking.find({
      service: serviceId,
      date: { $gte: startOfDay, $lte: endOfDay },
      status: { $ne: 'cancelled' }
    });
    
    // Filter out booked slots
    const bookedTimes = bookings.map(booking => booking.date.getTime());
    const availableTimes = availableSlots.filter(slot => !bookedTimes.includes(slot.getTime()));
    
    res.status(200).json({
      success: true,
      count: availableTimes.length,
      data: availableTimes
    });
  } catch (error) {
    next(error);
  }
};

// Helper function to send booking confirmation email
const sendBookingConfirmationEmail = async (booking, service, user) => {
  try {
    const transporter = nodemailer.createTransport({
      service: process.env.EMAIL_SERVICE,
      auth: {
        user: process.env.EMAIL_USERNAME,
        pass: process.env.EMAIL_PASSWORD
      }
    });
    
    const bookingDate = new Date(booking.date);
    const formattedDate = bookingDate.toLocaleDateString();
    const formattedTime = bookingDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    const message = `
      Dear ${user.name},
      
      Thank you for your booking with us!
      
      Booking Details:
      - Service: ${service.name}
      - Date: ${formattedDate}
      - Time: ${formattedTime}
      - Duration: ${service.duration} minutes
      - Price: $${service.price}
      
      Your booking status is: ${booking.status}
      
      If you need to make any changes to your booking, please contact us or log in to your account.
      
      Thank you for choosing our services!
    `;
    
    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to: user.email,
      subject: 'Booking Confirmation',
      text: message
    });
    
  } catch (error) {
    console.error('Email sending failed', error);
  }
};