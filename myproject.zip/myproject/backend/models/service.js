const mongoose = require('mongoose');

const ServiceSchema = new mongoose.Schema({
  name: {
    type: String,
    trim: true,
    required: [true, 'Please provide a service name']
  },
  description: {
    type: String,
    required: [true, 'Please provide a description']
  },
  price: {
    type: Number,
    required: [true, 'Please add a price']
  },
  duration: {
    type: Number,
    required: [true, 'Please specify the duration in minutes']
  },
  image: {
    type: String,
    default: 'default-service.jpg'
  },
  category: {
    type: String,
    required: [true, 'Please specify a category']
  },
  isAvailable: {
    type: Boolean,
    default: true
  },
  availableTimes: {
    monday: {
      start: String,
      end: String,
      isAvailable: { type: Boolean, default: true }
    },
    tuesday: {
      start: String,
      end: String,
      isAvailable: { type: Boolean, default: true }
    },
    wednesday: {
      start: String,
      end: String,
      isAvailable: { type: Boolean, default: true }
    },
    thursday: {
      start: String,
      end: String,
      isAvailable: { type: Boolean, default: true }
    },
    friday: {
      start: String,
      end: String,
      isAvailable: { type: Boolean, default: true }
    },
    saturday: {
      start: String,
      end: String,
      isAvailable: { type: Boolean, default: true }
    },
    sunday: {
      start: String,
      end: String,
      isAvailable: { type: Boolean, default: true }
    }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Get available time slots for a specific date
ServiceSchema.methods.getAvailableTimeSlots = function(date) {
  const requestedDate = new Date(date);
  const dayOfWeek = requestedDate.getDay(); // 0 for Sunday, 1 for Monday, etc.
  
  const daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const dayName = daysOfWeek[dayOfWeek];
  
  // Check if service is available on the requested day
  const daySettings = this.availableTimes[dayName];
  if (!daySettings.isAvailable || !daySettings.start || !daySettings.end) {
    return [];
  }
  
  // Parse start and end times
  const [startHour, startMinute] = daySettings.start.split(':').map(Number);
  const [endHour, endMinute] = daySettings.end.split(':').map(Number);
  
  // Generate time slots based on service duration
  const slots = [];
  const slotDuration = this.duration;
  
  let currentTime = new Date(requestedDate);
  currentTime.setHours(startHour, startMinute, 0, 0);
  
  const endTime = new Date(requestedDate);
  endTime.setHours(endHour, endMinute, 0, 0);
  
  while (currentTime < endTime) {
    slots.push(new Date(currentTime));
    currentTime = new Date(currentTime.getTime() + slotDuration * 60000);
  }
  
  return slots;
};

module.exports = mongoose.model('service', ServiceSchema);