const express = require('express');
const {
  getBookings,
  getBooking,
  createBooking,
  updateBooking,
  deleteBooking,
  cancelBooking,
  getAvailableTimeSlots
} = require('../controllers/bookingcontroller');

const router = express.Router();

// Import middleware
const { protect } = require('../middleware/auth');

router.route('/')
  .get(protect, getBookings)
  .post(protect, createBooking);

router.route('/:id')
  .get(protect, getBooking)
  .put(protect, updateBooking)
  .delete(protect, deleteBooking);

router.put('/:id/cancel', protect, cancelBooking);
router.get('/availability/:serviceId/:date', protect, getAvailableTimeSlots);

module.exports = router;