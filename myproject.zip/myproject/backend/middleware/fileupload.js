const path = require('path');
const fileUpload = require('express-fileupload');
const fs = require('fs');

// Configure file upload middleware
const configureFileUpload = (app) => {
  // Create upload directory if it doesn't exist
  const uploadDir = process.env.FILE_UPLOAD_PATH || './public/uploads';
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }
  
  // File upload middleware
  app.use(fileUpload({
    createParentPath: true,
    limits: { fileSize: 1000000 }, // 1MB max file size
    abortOnLimit: true,
    responseOnLimit: 'File size is too large. Maximum file size is 1MB.',
    useTempFiles: true,
    tempFileDir: '/tmp/',
    preserveExtension: true,
    safeFileNames: true
  }));
  
  // Serve static files from upload directory
  app.use('/uploads', express.static(path.join(__dirname, '..', uploadDir)));
};

module.exports = configureFileUpload;