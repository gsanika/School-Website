import React, { createContext, useState, useEffect } from 'react';

// Create context
export const BookingContext = createContext();

// Create provider component
export const BookingProvider = ({ children }) => {
  // Initialize state from localStorage if available
  const [bookingData, setBookingData] = useState(() => {
    const savedBookingData = localStorage.getItem('bookingData');
    if (savedBookingData) {
      try {
        // Parse saved data and handle dates properly
        const parsed = JSON.parse(savedBookingData);
        
        // Convert date string back to Date object if it exists
        if (parsed.date) {
          parsed.date = new Date(parsed.date);
        }
        
        return parsed;
      } catch (error) {
        console.error('Error parsing saved booking data:', error);
        return {};
      }
    }
    return {};
  });

  // Save booking data to localStorage whenever it changes
  useEffect(() => {
    // Only save if there's actual data
    if (Object.keys(bookingData).length > 0) {
      try {
        localStorage.setItem('bookingData', JSON.stringify(bookingData));
      } catch (error) {
        console.error('Error saving booking data to localStorage:', error);
      }
    }
  }, [bookingData]);

  // Clear booking data
  const clearBookingData = () => {
    setBookingData({});
    localStorage.removeItem('bookingData');
  };

  // Reset just the current service selection
  const resetServiceSelection = () => {
    setBookingData(prevData => {
      const { service, ...rest } = prevData;
      return rest;
    });
  };

  // Method to update just a specific field
  const updateBookingField = (field, value) => {
    setBookingData(prevData => ({
      ...prevData,
      [field]: value
    }));
  };

  // Check if booking data has minimum required fields
  const hasMinimumBookingData = () => {
    return bookingData.service && bookingData.date && bookingData.time && 
           bookingData.formData && bookingData.formData.name &&
           bookingData.formData.email && bookingData.formData.phone &&
           bookingData.formData.address;
  };

  return (
    <BookingContext.Provider 
      value={{ 
        bookingData, 
        setBookingData, 
        clearBookingData,
        resetServiceSelection,
        updateBookingField,
        hasMinimumBookingData
      }}
    >
      {children}
    </BookingContext.Provider>
  );
};

export default BookingProvider;