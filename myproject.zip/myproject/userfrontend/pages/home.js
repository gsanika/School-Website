import React from 'react';
import ServiceCard from '../components/ServiceCard';
import Footer from '../components/Footer';

const Home = () => {
  const featuredServices = [
    {
      id: 1,
      title: "Standard Cleaning",
      description: "A thorough cleaning of all rooms with eco-friendly products.",
      price: 89,
      duration: "2 hours",
      image: "/images/standard-cleaning.jpg"
    },
    {
      id: 2,
      title: "Deep Cleaning",
      description: "An intensive cleaning service that reaches every corner and crevice.",
      price: 149,
      duration: "4 hours",
      image: "/images/deep-cleaning.jpg"
    },
    {
      id: 3,
      title: "Move-in/Move-out",
      description: "Prepare your space for new tenants or make it spotless when you leave.",
      price: 199,
      duration: "5 hours",
      image: "/images/move-in-out.jpg"
    }
  ];

  return (
    <div className="home-container">
      <header className="hero-section">
        <div className="hero-overlay">
          <h1>Professional Cleaning Services</h1>
          <p>Spotless spaces, happy faces. Book your cleaning service today!</p>
          <button 
            className="cta-button"
            onClick={() => window.location.href = '/booking'}
          >
            Book Now
          </button>
        </div>
      </header>

      <section className="about-section">
        <h2>Why Choose Us?</h2>
        <div className="features-grid">
          <div className="feature">
            <i className="feature-icon quality-icon"></i>
            <h3>Quality Service</h3>
            <p>Our professional cleaners are trained to deliver exceptional results every time.</p>
          </div>
          <div className="feature">
            <i className="feature-icon eco-icon"></i>
            <h3>Eco-Friendly</h3>
            <p>We use environmentally safe cleaning products for your health and the planet.</p>
          </div>
          <div className="feature">
            <i className="feature-icon reliability-icon"></i>
            <h3>Reliability</h3>
            <p>Count on us to arrive on time and complete the job with attention to detail.</p>
          </div>
        </div>
      </section>

      <section className="services-preview">
        <h2>Our Popular Services</h2>
        <div className="services-grid">
          {featuredServices.map(service => (
            <ServiceCard key={service.id} service={service} />
          ))}
        </div>
        <div className="view-all">
          <a href="/services" className="view-all-link">View All Services</a>
        </div>
      </section>

      <section className="testimonials">
        <h2>What Our Customers Say</h2>
        <div className="testimonial-carousel">
          <div className="testimonial">
            <p>"The team did an amazing job with our end-of-lease cleaning. Would highly recommend!"</p>
            <span className="customer-name">- Sarah T.</span>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Home;